SELECT * FROM dimproduct;
-- PUNTO UNO
SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, S.EnglishProductSubcategoryName FROM dimproduct AS P
INNER JOIN dimproductsubcategory AS S 
ON P.ProductSubcategoryKey = S.ProductSubcategoryKey;
-- PUNTO DUE
SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, S.EnglishProductSubcategoryName, C.ProductCategoryKey FROM dimproduct AS P
INNER JOIN dimproductsubcategory AS S 
ON P.ProductSubcategoryKey = S.ProductSubcategoryKey
INNER JOIN dimproductcategory AS C
ON S.ProductCategoryKey = C.ProductCategoryKey;
-- PUNTO TRE
SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, O.OrderDate FROM dimproduct AS P
INNER JOIN factresellersales AS O
ON P.ProductKey = O.ProductKey;
-- PUNTO QUATTRO
 SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, P.FinishedGoodsFlag, O.OrderDate FROM dimproduct AS P
LEFT OUTER JOIN factresellersales AS O
ON P.ProductKey = O.ProductKey
WHERE P.FinishedGoodsFlag = 1 AND O.OrderDate IS NULL;
-- PUNTO CINQUE
select * from dimreseller ;
-- punto sei
 SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, P.FinishedGoodsFlag, O.OrderDate, sc.ProductCategoryKey FROM dimproduct AS P
 JOIN factresellersales AS O
 on P.ProductKey = O.ProductKey
 JOIN dimproductsubcategory as sc
 ON P.ProductSubcategoryKey = sc.ProductSubcategoryKey;
 SELECT P.ProductKey, P.ProductSubcategoryKey, P.EnglishProductName, P.ListPrice, P.FinishedGoodsFlag, O.OrderDate, sc.ProductCategoryKey FROM dimproduct AS P
 JOIN factresellersales AS O
 on P.ProductKey = O.ProductKey
 JOIN dimproductsubcategory as sc
 ON P.ProductSubcategoryKey = sc.ProductSubcategoryKey;
 -- punto sette e otto
 SELECT dr.ResellerKey, dr.GeographyKey, dr.BusinessType, dr.AnnualRevenue, dr.NumberEmployees FROM dimreseller dr;
 -- punto nove
 SELECT rs.ResellerName,
 s.SalesOrderNumber AS NumeroOrdini,
 s.SalesOrderLineNumber, 
 s.OrderDate, 
 s.UnitPrice, 
 s.OrderQuantity as Quantita , 
 s.TotalProductCost,
rs.ResellerName as Store,
 g.EnglishCountryRegionName,
 p.EnglishProductName as Nome,
 ds.EnglishProductSubcategoryName AS Sottocategoria,
 c.EnglishProductCategoryName as Categoria
 
FROM dimreseller AS rs
JOIN factresellersales s
ON rs.ResellerKey = s.ResellerKey
JOIN dimgeography as g
on rs.GeographyKey = g.GeographyKey 
JOIN dimproduct as p
ON p.ProductKey = s.ProductKey
JOIN dimproductsubcategory as ds
ON p.ProductSubcategoryKey = ds.ProductSubcategoryKey
join dimproductcategory as c
on ds.ProductCategoryKey = c.ProductCategoryKey;


 