create database ToysGroup
;


CREATE TABLE product (
product_id int unsigned not null auto_increment,
product_name varchar(100),
unit_price decimal (6,2),
category varchar(50),
brand varchar(50),
quantity int,
production_date datetime not null,
PRIMARY KEY (product_id)
)

;
create table region
		(region_id int unsigned not null auto_increment,
		region_name varchar(100),
		store_category varchar (50),
        store_name varchar (50),

PRIMARY KEY (region_id)
)
;
   
-- tabella vendite e regione
create table sales
		(order_id int unsigned not null auto_increment,
		product_id int unsigned not null, 
		region_id int unsigned not null, 
		quantity smallint,
		unitprice decimal (6,2),
        orderdate datetime not null ,
        
PRIMARY KEY  (order_id),
  KEY idx_fk_product_id (product_id),
  KEY idx_fk_address_id (region_id),
  CONSTRAINT fk_Sales_Product FOREIGN KEY (product_id) REFERENCES Product (product_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_Sales_Region FOREIGN KEY (region_id) REFERENCES Region (region_id) ON DELETE RESTRICT ON UPDATE CASCADE
)

;
-- popolare le tabelle

insert product values
(1, 'Robot', 199.99, 'Toys', 'ToyCo', 50, '2024-04-30 09:00:00'),
(2, 'Doll', 149.99, 'Toys', 'ToyCo', 40, '2024-04-30 09:15:00'),
(3, 'Remote Control Car', 99.99, 'Toys', 'ToyCo', 30, '2024-04-30 09:30:00'),
(4, 'Action Figure', 49.99, 'Toys', 'ToyCo', 20, '2024-04-30 09:45:00'),
(5, 'Board Game', 29.99, 'Toys', 'ToyCo', 35, '2024-04-30 10:00:00'),
(6, 'Puzzle', 19.99, 'Toys', 'ToyCo', 25, '2024-04-30 10:15:00'),
(7, 'Stuffed Animal', 9.99, 'Toys', 'ToyCo', 15, '2024-04-30 10:30:00'),
(8, 'Building Blocks', 4.99, 'Toys', 'ToyCo', 10, '2024-04-30 10:45:00'),
(9, 'Toy Train', 3.99, 'Toys', 'ToyCo', 22, '2024-04-30 11:00:00'),
(10, 'Yo-yo', 2.99, 'Toys', 'ToyCo', 18, '2024-04-30 11:15:00'),
(11, 'Kite', 499.99, 'Outdoor', 'FunCo', 28, '2024-04-30 11:30:00'),
(12, 'Remote Control Helicopter', 399.99, 'Outdoor', 'FunCo', 17, '2024-04-30 11:45:00'),
(13, 'Water Gun', 299.99, 'Outdoor', 'FunCo', 12, '2024-04-30 12:00:00'),
(14, 'Soccer Ball', 199.99, 'Sports', 'SportyCo', 20, '2024-04-30 12:15:00'),
(15, 'Basketball', 149.99, 'Sports', 'SportyCo', 15, '2024-04-30 12:30:00'),
(16, 'Baseball Glove', 99.99, 'Sports', 'SportyCo', 10, '2024-04-30 12:45:00'),
(17, 'Jump Rope', 49.99, 'Sports', 'SportyCo', 25, '2024-04-30 13:00:00'),
(18, 'Frisbee', 29.99, 'Outdoor', 'FunCo', 30, '2024-04-30 13:15:00'),
(19, 'Hula Hoop', 19.99, 'Outdoor', 'FunCo', 35, '2024-04-30 13:30:00'),
(20, 'Sidewalk Chalk', 9.99, 'Outdoor', 'FunCo', 40, '2024-04-30 13:45:00'),
(21, 'Bubble Wand', 4.99, 'Outdoor', 'FunCo', 45, '2024-04-30 14:00:00'),
(22, 'Sandbox Bucket and Shovel', 3.99, 'Outdoor', 'FunCo', 50, '2024-04-30 14:15:00'),
(23, 'Tennis Ball', 499.99, 'Sports', 'SportyCo', 8, '2024-04-30 14:30:00'),
(24, 'Tennis Racket', 399.99, 'Sports', 'SportyCo', 5, '2024-04-30 14:45:00'),
(25, 'Golf Club', 299.99, 'Sports', 'SportyCo', 15, '2024-04-30 15:00:00'),
(26, 'Skateboard', 199.99, 'Sports', 'SportyCo', 20, '2024-04-30 15:15:00'),
(27, 'Bicycle', 149.99, 'Sports', 'SportyCo', 10, '2024-04-30 15:30:00'),
(28, 'Rollerblades', 99.99, 'Sports', 'SportyCo', 25, '2024-04-30 15:45:00'),
(29, 'Snow Sled', 49.99, 'Outdoor', 'FunCo', 30, '2024-04-30 16:00:00'),
(30, 'Beach Ball', 29.99, 'Outdoor', 'FunCo', 35, '2024-04-30 16:15:00'),
(31, 'Pool Float', 19.99, 'Outdoor', 'FunCo', 40, '2024-04-30 16:30:00'),
(32, 'Sandcastle Mold Set', 9.99, 'Outdoor', 'FunCo', 45, '2024-04-30 16:45:00'),
(33, 'Water Balloons', 4.99, 'Outdoor', 'FunCo', 50, '2024-04-30 17:00:00'),
(34, 'Flying Disc', 3.99, 'Outdoor', 'FunCo', 22, '2024-04-30 17:15:00'),
(35, 'Toy Binoculars', 499.99, 'Adventure', 'ExploreCo', 28, '2024-04-30 17:30:00'),
(36, 'Compass', 399.99, 'Adventure', 'ExploreCo', 17, '2024-04-30 17:45:00'),
(37, 'Flashlight', 299.99, 'Adventure', 'ExploreCo', 12, '2024-04-30 18:00:00'),
(38, 'Tent', 199.99, 'Adventure', 'ExploreCo', 20, '2024-04-30 18:15:00'),
(39, 'Sleeping Bag', 149.99, 'Adventure', 'ExploreCo', 15, '2024-04-30 18:30:00'),
(40, 'Binoculars', 99.99, 'Adventure', 'ExploreCo', 10, '2024-04-30 18:45:00'),
(41, 'Backpack', 49.99, 'Adventure', 'ExploreCo', 25, '2024-04-30 19:00:00'),
(42, 'Camping Stove', 29.99, 'Adventure', 'ExploreCo', 30, '2024-04-30 19:15:00'),
(43, 'Water Bottle', 19.99, 'Adventure', 'ExploreCo', 35, '2024-04-30 19:30:00'),
(44, 'Survival Kit', 9.99, 'Adventure', 'ExploreCo', 40, '2024-04-30 19:45:00'),
(45, 'Hiking Boots', 4.99, 'Adventure', 'ExploreCo', 45, '2024-04-30 20:00:00'),
(46, 'Fishing Rod', 3.99, 'Adventure', 'ExploreCo', 50, '2024-04-30 20:15:00'),
(47, 'Toy Microscope', 499.99, 'Education', 'LearnCo', 28, '2024-04-30 20:30:00'),
(48, 'Chemistry Set', 399.99, 'Education', 'LearnCo', 17, '2024-04-30 20:45:00'),
(49, 'Telescope', 299.99, 'Education', 'LearnCo', 12, '2024-04-30 21:00:00'),
(50, 'Globe', 199.99, 'Education', 'LearnCo', 20, '2024-04-30 21:15:00');

insert region values
(1, 'North America', 'Online', 'North America Toys'),
(2, 'South America', 'Reseller', 'South America Toys'),
(3, 'Europe', 'Online', 'Europe Toys'),
(4, 'Asia', 'Reseller', 'Asia Toys'),
(5, 'Africa', 'Online', 'Africa Toys'),
(6, 'Oceania', 'Reseller', 'Oceania Toys'),
(7, 'Antarctica', 'Online', 'Antarctica Toys'),
(8, 'Arctic', 'Reseller', 'Arctic Toys'),
(9, 'Indian Ocean', 'Online', 'Indian Ocean Toys'),
(10, 'Atlantic Ocean', 'Reseller', 'Atlantic Ocean Toys'),
(11, 'Pacific Ocean', 'Online', 'Pacific Ocean Toys'),
(12, 'Mediterranean Sea', 'Reseller', 'Mediterranean Sea Toys'),
(13, 'Caribbean Sea', 'Online', 'Caribbean Sea Toys'),
(14, 'South China Sea', 'Reseller', 'South China Sea Toys'),
(15, 'Arabian Sea', 'Online', 'Arabian Sea Toys'),
(16, 'Bay of Bengal', 'Reseller', 'Bay of Bengal Toys'),
(17, 'Bering Sea', 'Online', 'Bering Sea Toys'),
(18, 'Gulf of Mexico', 'Reseller', 'Gulf of Mexico Toys'),
(19, 'Gulf of Guinea', 'Online', 'Gulf of Guinea Toys'),
(20, 'Hudson Bay', 'Reseller', 'Hudson Bay Toys');

insert sales values
(1, 10, 8, 12, 49.99, '2024-04-01 08:00:00'),
(2, 15, 16, 5, 29.99, '2024-04-02 10:15:00'),
(3, 8, 4, 20, 99.99, '2024-04-03 12:30:00'),
(4, 4, 19, 7, 19.99, '2024-04-04 14:45:00'),
(5, 12, 7, 10, 39.99, '2024-04-05 17:00:00'),
(6, 6, 13, 15, 59.99, '2024-04-06 19:15:00'),
(7, 18, 2, 25, 79.99, '2024-04-07 21:30:00'),
(8, 14, 11, 8, 29.99, '2024-04-08 23:45:00'),
(9, 9, 18, 4, 49.99, '2024-04-09 02:00:00'),
(10, 20, 5, 14, 19.99, '2024-04-10 04:15:00'),
(11, 3, 20, 21, 29.99, '2024-04-11 06:30:00'),
(12, 7, 10, 2, 39.99, '2024-04-12 08:45:00'),
(13, 2, 17, 17, 59.99, '2024-04-13 11:00:00'),
(14, 17, 9, 22, 79.99, '2024-04-14 13:15:00'),
(15, 11, 3, 11, 99.99, '2024-04-15 15:30:00'),
(16, 19, 15, 6, 29.99, '2024-04-16 17:45:00'),
(17, 5, 1, 28, 49.99, '2024-04-17 20:00:00'),
(18, 8, 12, 9, 19.99, '2024-04-18 22:15:00'),
(19, 16, 6, 16, 29.99, '2024-04-19 00:30:00'),
(20, 1, 14, 23, 39.99, '2024-04-20 02:45:00'),
(21, 13, 19, 10, 59.99, '2024-04-21 05:00:00'),
(22, 19, 8, 27, 79.99, '2024-04-22 07:15:00'),
(23, 11, 4, 1, 99.99, '2024-04-23 09:30:00'),
(24, 16, 10, 18, 29.99, '2024-04-24 11:45:00'),
(25, 4, 2, 3, 49.99, '2024-04-25 14:00:00'),
(26, 18, 7, 24, 19.99, '2024-04-26 16:15:00'),
(27, 20, 13, 5, 29.99, '2024-04-27 18:30:00'),
(28, 10, 20, 12, 39.99, '2024-04-28 20:45:00'),
(29, 12, 1, 19, 59.99, '2024-04-29 23:00:00'),
(30, 1, 15, 26, 79.99, '2024-04-30 01:15:00'),
(31, 16, 9, 13, 99.99, '2024-05-01 03:30:00'),
(32, 7, 16, 4, 29.99, '2024-05-02 05:45:00'),
(33, 19, 18, 29, 49.99, '2024-05-03 08:00:00'),
(34, 9, 5, 6, 19.99, '2024-05-04 10:15:00')
;
-- query 
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT 		p.product_name, 
			date_format ( s.orderdate,'%Y') AS sale_year,
            SUM(s.quantity * s.unitprice) as Fatturato
FROM 		sales  s
INNER JOIN  product  p using (product_id)
GROUP BY    sale_year, p.product_name
ORDER BY    Fatturato desc
;
      

--  3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 		s.order_id,
            SUM(s.quantity * s.unitprice) as fatturato,
            date_format ( s.orderdate,'%Y') AS sale_year,
			r.region_name
FROM 		sales  s
INNER JOIN  region r using (region_id)
GROUP BY    r.region_name, sale_year, s.order_id
ORDER by 	sale_year DESC, fatturato DESC
;
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT      SUM(s.quantity * s.unitprice) as fatturato,
			p.category
FROM        sales s
JOIN        product p USING (product_id)
GROUP BY    p.category
ORDER BY    fatturato desc
;
-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
select      p.product_id,
			p.product_name,
            s.order_id
from        product p
left outer join        sales s using(product_id)
where s.order_id is null
;
--
SELECT		p.product_name
FROM		product as p
WHERE		p.product_id not in (SELECT sales.product_id from sales)
;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 		p.product_name,
			MAX(s.orderdate) as lastdate
FROM		product p
LEFT JOIN	sales s using(product_id)
GROUP by 	p.product_name
ORDER by    lastdate desc
;